// City Hub backend: สมาชิก / ล็อกอิน / ยอดเงิน / เติมเงินซองอั่งเปา TrueMoney / จัดการสินค้า (แอดมิน)
// ติดตั้ง:  npm install
// รัน:      JWT_SECRET=ข้อความสุ่มยาวๆ TRUEMONEY_PHONE=08xxxxxxxx ADMIN_USERNAME=ชื่อแอดมิน node server.js
// เปิดเว็บที่ http://localhost:3000  (เซิร์ฟเวอร์เสิร์ฟหน้าเว็บให้เอง จึงไม่ต้องตั้งค่า API)
const express = require("express");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const path = require("path");

const { JWT_SECRET, TRUEMONEY_PHONE, ADMIN_USERNAME = "", PORT = 3000 } = process.env;
if (!JWT_SECRET || JWT_SECRET.length < 24) { console.error("ตั้ง JWT_SECRET ให้ยาวอย่างน้อย 24 ตัวอักษร"); process.exit(1); }
if (!/^0\d{9}$/.test(TRUEMONEY_PHONE || "")) console.warn("ยังไม่ได้ตั้ง TRUEMONEY_PHONE (เบอร์ 10 หลัก) ระบบเติมเงินจะใช้ไม่ได้");

const db = new Database(process.env.DB_FILE || "data.db");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE COLLATE NOCASE, email TEXT UNIQUE COLLATE NOCASE,
  hash TEXT NOT NULL, balance REAL NOT NULL DEFAULT 0, role TEXT NOT NULL DEFAULT 'user', created TEXT);
CREATE TABLE IF NOT EXISTS vouchers(code TEXT PRIMARY KEY, user_id INTEGER, amount REAL, at TEXT);
CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY, t INTEGER, data TEXT NOT NULL);`);

if (ADMIN_USERNAME) db.prepare("UPDATE users SET role='admin' WHERE username=?").run(ADMIN_USERNAME);

if (!db.prepare("SELECT 1 FROM products LIMIT 1").get()) {
  const seed = [
    { n: "สคริปต์ A (รายวัน)", c: "สคริปต์", p: 49, i: "⚡", d: "ใช้งานได้ 1 วัน อัปเดตสม่ำเสมอ", b: "ใหม่", bc: "blue" },
    { n: "สคริปต์ A (รายเดือน)", c: "สคริปต์", p: 299, old: 399, i: "🚀", d: "ใช้งานได้ 30 วัน คุ้มกว่า", b: "ลด 25%", bc: "red" },
    { n: "ชุดเครื่องมือ B", c: "เครื่องมือ", p: 149, i: "🛠️", d: "รวมเครื่องมือช่วยหลายอย่าง", b: "", bc: "blue" },
    { n: "แพ็กเกจ VIP", c: "แพ็กเกจ", p: 599, i: "👑", d: "ปลดล็อกทุกสคริปต์ + ซัพพอร์ตก่อนใคร", b: "ขายดี", bc: "orange" }
  ];
  const ins = db.prepare("INSERT INTO products(id,t,data) VALUES(?,?,?)");
  seed.forEach((x, k) => { const o = { ...x, id: "s" + k, hide: false, t: k + 1 }; ins.run(o.id, o.t, JSON.stringify(o)); });
}

const app = express();
app.set("trust proxy", 1);
app.use(express.json({ limit: "20kb" }));
if (process.env.SITE_ORIGIN) app.use(require("cors")({ origin: process.env.SITE_ORIGIN, allowedHeaders: ["Content-Type", "Authorization"] }));

// จำกัดจำนวนครั้งต่อ IP
const hits = new Map();
const limit = (key, max, ms) => (req, res, next) => {
  const k = key + req.ip, n = Date.now(), a = (hits.get(k) || []).filter(t => n - t < ms);
  a.push(n); hits.set(k, a);
  a.length > max ? res.status(429).json({ message: "ลองบ่อยเกินไป กรุณารอสักครู่" }) : next();
};

const pub = u => ({ username: u.username, balance: u.balance, role: u.role });
const sign = u => jwt.sign({ id: u.id }, JWT_SECRET, { expiresIn: "30d" });
function auth(req, res, next) {
  const m = /^Bearer (.+)$/.exec(req.headers.authorization || "");
  try {
    const { id } = jwt.verify(m ? m[1] : "", JWT_SECRET);
    req.user = db.prepare("SELECT * FROM users WHERE id=?").get(id);
  } catch { /* ignore */ }
  req.user ? next() : res.status(401).json({ message: "กรุณาเข้าสู่ระบบ" });
}
const admin = (req, res, next) => req.user.role === "admin" ? next() : res.status(403).json({ message: "เฉพาะแอดมิน" });

// สมัครสมาชิก
app.post("/api/register", limit("reg", 10, 3600e3), (req, res) => {
  const { username = "", email = "", password = "" } = req.body || {};
  if (!/^[A-Za-z0-9_]{4,13}$/.test(username)) return res.status(400).json({ message: "ชื่อผู้ใช้ไม่ถูกต้อง" });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || email.length > 120) return res.status(400).json({ message: "อีเมลไม่ถูกต้อง" });
  if (password.length < 8 || password.length > 100 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) return res.status(400).json({ message: "รหัสผ่านไม่ปลอดภัยพอ" });
  if (db.prepare("SELECT 1 FROM users WHERE username=? OR email=?").get(username, email)) return res.status(409).json({ message: "ชื่อผู้ใช้หรืออีเมลนี้ถูกใช้แล้ว" });
  const role = ADMIN_USERNAME && username.toLowerCase() === ADMIN_USERNAME.toLowerCase() ? "admin" : "user";
  db.prepare("INSERT INTO users(username,email,hash,role,created) VALUES(?,?,?,?,?)")
    .run(username, email.toLowerCase(), bcrypt.hashSync(password, 11), role, new Date().toISOString());
  res.json({ ok: true });
});

// เข้าสู่ระบบ
app.post("/api/login", limit("login", 15, 600e3), (req, res) => {
  const { id = "", password = "" } = req.body || {};
  const u = db.prepare("SELECT * FROM users WHERE username=? OR email=?").get(String(id), String(id).toLowerCase());
  const ok = bcrypt.compareSync(String(password), u ? u.hash : "$2a$11$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvali");
  if (!u || !ok) return res.status(401).json({ message: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });
  res.json({ token: sign(u), user: pub(u) });
});

app.get("/api/me", auth, (req, res) => res.json(pub(req.user)));

// สินค้า
const COLORS = ["red", "orange", "green", "blue", "purple"];
const rows = () => db.prepare("SELECT data FROM products ORDER BY t").all().map(r => JSON.parse(r.data));
app.get("/api/products", (req, res) => {
  let isAdmin = false;
  if (req.query.all) {
    try { const m = /^Bearer (.+)$/.exec(req.headers.authorization || ""); const { id } = jwt.verify(m[1], JWT_SECRET);
      isAdmin = db.prepare("SELECT role FROM users WHERE id=?").get(id)?.role === "admin"; } catch { /* guest */ }
  }
  res.json(rows().filter(p => isAdmin || !p.hide));
});
app.post("/api/products/save", auth, admin, (req, res) => {
  const b = req.body || {}, str = (v, n) => String(v ?? "").slice(0, n);
  const p = Number(b.p), old = b.old == null ? null : Number(b.old);
  if (!/^[A-Za-z0-9_-]{1,40}$/.test(String(b.id)) || !str(b.n, 60).trim() || !(p >= 0) || (old != null && !(old >= 0)))
    return res.status(400).json({ message: "ข้อมูลสินค้าไม่ถูกต้อง" });
  const o = { id: b.id, n: str(b.n, 60), c: str(b.c, 30) || "ทั่วไป", p, old, i: str(b.i, 8) || "📦", d: str(b.d, 120),
    b: str(b.b, 14), bc: COLORS.includes(b.bc) ? b.bc : "blue", hide: !!b.hide, t: Number(b.t) || Date.now() };
  db.prepare("INSERT INTO products(id,t,data) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET t=excluded.t,data=excluded.data")
    .run(o.id, o.t, JSON.stringify(o));
  res.json({ ok: true });
});
app.post("/api/products/delete", auth, admin, (req, res) => {
  db.prepare("DELETE FROM products WHERE id=?").run(String(req.body?.id || ""));
  res.json({ ok: true });
});

// เติมเงินด้วยซองอั่งเปา TrueMoney (ยอดเข้าบัญชีของผู้ใช้ที่ล็อกอินอยู่เท่านั้น)
app.post("/api/topup", auth, limit("topup", 10, 300e3), async (req, res) => {
  if (!/^0\d{9}$/.test(TRUEMONEY_PHONE || "")) return res.status(503).json({ message: "ร้านยังไม่ได้ตั้งค่า TrueMoney" });
  const m = /^https:\/\/gift\.truemoney\.com\/campaign\/\?v=([0-9A-Za-z]{18,})$/.exec(String(req.body?.link || "").trim());
  if (!m) return res.status(400).json({ message: "ลิงก์อั่งเปาไม่ถูกต้อง" });
  const code = m[1];
  try { db.prepare("INSERT INTO vouchers(code,user_id,amount,at) VALUES(?,?,0,?)").run(code, req.user.id, new Date().toISOString()); }
  catch { return res.status(409).json({ message: "ซองนี้ถูกใช้ไปแล้ว" }); }   // กันซ้ำ/กันกดพร้อมกัน
  const undo = () => db.prepare("DELETE FROM vouchers WHERE code=? AND amount=0").run(code);
  try {
    const r = await fetch(`https://gift.truemoney.com/campaign/vouchers/${code}/redeem`, {
      method: "POST", headers: { "Content-Type": "application/json", "User-Agent": "Mozilla/5.0" },
      body: JSON.stringify({ mobile: TRUEMONEY_PHONE, voucher_hash: code }), signal: AbortSignal.timeout(15000)
    });
    const d = await r.json();
    if (d?.status?.code !== "SUCCESS") {
      undo();
      const map = { VOUCHER_OUT_OF_STOCK: "ซองนี้ถูกรับไปหมดแล้ว", VOUCHER_NOT_FOUND: "ไม่พบซองนี้", VOUCHER_EXPIRED: "ซองหมดอายุแล้ว", TARGET_USER_REDEEMED: "ซองนี้ถูกรับไปแล้ว" };
      return res.status(400).json({ message: map[d?.status?.code] || "แลกซองไม่สำเร็จ" });
    }
    const amount = Number(d.data?.my_ticket?.amount_baht);
    if (!(amount > 0)) { console.error("อ่านยอดจากซองไม่ได้", code); return res.status(502).json({ message: "อ่านจำนวนเงินไม่ได้ กรุณาติดต่อแอดมิน" }); }
    db.transaction(() => {
      db.prepare("UPDATE vouchers SET amount=? WHERE code=?").run(amount, code);
      db.prepare("UPDATE users SET balance=balance+? WHERE id=?").run(amount, req.user.id);
    })();
    res.json({ ok: true, amount, balance: db.prepare("SELECT balance FROM users WHERE id=?").get(req.user.id).balance });
  } catch (e) { undo(); res.status(502).json({ message: "ติดต่อ TrueMoney ไม่ได้ กรุณาลองใหม่" }); }
});

// เสิร์ฟหน้าเว็บ: ตั้ง API ให้ชี้มาที่เซิร์ฟเวอร์นี้อัตโนมัติ
app.get("/", (req, res) => {
  const html = fs.readFileSync(path.join(__dirname, "public", "index.html"), "utf8").replace('const API=/*API*/""', "const API=location.origin");
  res.type("html").send(html);
});

app.listen(PORT, () => console.log("City Hub พร้อมใช้งานที่ http://localhost:" + PORT));
