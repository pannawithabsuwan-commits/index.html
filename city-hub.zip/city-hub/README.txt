City Hub - วิธีรัน
1) ติดตั้ง Node.js 18 ขึ้นไป แล้วในโฟลเดอร์นี้พิมพ์:  npm install
2) รัน (Linux/Mac):
   JWT_SECRET="ข้อความสุ่มยาวๆ" TRUEMONEY_PHONE=08xxxxxxxx ADMIN_USERNAME=ชื่อแอดมิน node server.js
   (Windows PowerShell: $env:JWT_SECRET="..."; $env:TRUEMONEY_PHONE="08..."; $env:ADMIN_USERNAME="..."; node server.js)
3) เปิด http://localhost:3000
4) สมัครสมาชิกด้วยชื่อเดียวกับ ADMIN_USERNAME บัญชีนั้นจะเป็นแอดมิน (มีปุ่ม "จัดการร้าน")
ขึ้นออนไลน์: ใช้ VPS/โฮสต์ที่รัน Node ได้ (Railway, Render, Fly.io ฯลฯ) ใส่ HTTPS ด้านหน้า
ข้อมูลอยู่ในไฟล์ data.db ให้สำรองไฟล์นี้เป็นประจำ
